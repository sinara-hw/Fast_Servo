Variants:

TE0706-XX	USB A Receptacle assembled (currently 28.12.2018 standard)
TE0706-XX-D	micro USB assembled

